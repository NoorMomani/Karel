import stanford.karel.SuperKarel;


public class Homework extends SuperKarel {

    private int colsCounter, rowsCounter, moveCount;
    private void moveAndCount(){
        move();
        moveCount++;
    }
    private void checkAndPutBeeper(){
        if(!beepersPresent()) {
            putBeeper();
        }
    }
    private void continuousMoveAndCount(double times){
        for (int i = 0; i < times ; i++) {
            moveAndCount();
        }
    }
    private void continuousDraw(double times){
        for (int i = 0; i < times ; i++) {
            checkAndPutBeeper();
            if(i == times-1){
                break;
            }
            moveAndCount();

        }
    }
    public void DrawAndGoLeft(int times){
        continuousDraw(times);
        checkAndPutBeeper();
        turnLeft();
    }
    public void DrowLeft(int times){
        continuousDraw(times);
        turnLeft();
        moveAndCount();
        turnLeft();
    }
    public void DrawRight(){
        checkAndPutBeeper();
        turnRight();
        moveAndCount();
        turnRight();
    }
    public void CountRowAndCol(){
        boolean North = false, East = false;
        while(!East) {
            if (frontIsClear()) {
                move();
                if(North){ rowsCounter++; moveCount++;}
                else{ colsCounter++; moveCount++;}
            }
            else if (frontIsBlocked() && !North) { turnLeft(); North = true;}
            else if(frontIsBlocked()){ turnLeft(); East = true;}

        }
    }

    public void Draw() {

        if (rowsCounter % 2 == 1 && colsCounter % 2 == 1) {

            continuousMoveAndCount(Math.floor(colsCounter /2 ));
            turnLeft();

            continuousDraw((rowsCounter /2)+1 );
            turnLeft();

            continuousMoveAndCount(colsCounter /2);
            turnAround();

            continuousDraw(colsCounter);
            checkAndPutBeeper();
            turnAround();

            continuousMoveAndCount(colsCounter /2);
            turnRight();

            continuousDraw((rowsCounter /2)+1 );

            if(colsCounter == rowsCounter) {
                turnLeft();
                moveAndCount();
                turnLeft();
                moveAndCount();
                turnRight();

                continuousDraw((colsCounter / 2) - 1);
                turnLeft();
                continuousDraw(rowsCounter - 2);
                turnLeft();
                continuousDraw(colsCounter - 2);
                turnLeft();
                continuousDraw(rowsCounter - 2);
                turnLeft();

                continuousDraw((colsCounter / 2) - 1);
            }
            else{
                int Min = Math.min(colsCounter, rowsCounter);
                int num1 = (Min/2) - 1;

                turnAround();
                continuousMoveAndCount((rowsCounter /2)-num1);
                turnLeft();

                continuousDraw(num1+1);
                turnRight();
                continuousDraw((num1*2)+1);
                turnRight();
                continuousDraw((num1*2)+ 1);
                turnRight();
                continuousDraw((num1*2)+1);
                turnRight();
                continuousDraw((num1));
                turnRight();
            }
        }

        else if (rowsCounter % 2 == 0 && colsCounter % 2 == 0){

            continuousMoveAndCount(Math.floor(colsCounter /2 ));
            turnLeft();

            DrowLeft(rowsCounter);

            continuousDraw(rowsCounter);
            turnAround();

            continuousMoveAndCount((rowsCounter /2)-1);
            turnLeft();

            continuousDraw((colsCounter /2) );
            DrawRight();

            continuousDraw(colsCounter);
            DrawRight();

            continuousDraw((colsCounter /2) );
            turnLeft();
            moveAndCount();

            if(rowsCounter == colsCounter) {
                continuousMoveAndCount((rowsCounter / 2) - 3);
                turnLeft();
                moveAndCount();

                DrawAndGoLeft((colsCounter / 2) - 2);
                DrawAndGoLeft(rowsCounter - 2);
                DrawAndGoLeft(colsCounter - 2);
                DrawAndGoLeft(rowsCounter - 2);
                continuousDraw((colsCounter / 2) - 2);
            }
            else {
                int Min = Math.min(colsCounter, rowsCounter);
                int num = (Min/2) - 2;

                continuousMoveAndCount(num - 1);
                turnLeft();
                moveAndCount();

                DrawAndGoLeft(num);
                DrawAndGoLeft((num*2) + 2);
                DrawAndGoLeft((num*2) + 2);
                DrawAndGoLeft((num*2) + 2);
                continuousDraw(num);
            }
        }
        else if (rowsCounter % 2 == 1 && colsCounter % 2 == 0){
            int Min = Math.min(colsCounter, rowsCounter);
            int num1 = (Min/2);

            continuousMoveAndCount(Math.floor(colsCounter /2 ));
            turnLeft();

            DrowLeft(rowsCounter);

            continuousDraw(rowsCounter);
            turnAround();

            continuousMoveAndCount((rowsCounter /2));
            turnLeft();

            continuousMoveAndCount((colsCounter /2)-1);
            turnAround();

            continuousDraw(colsCounter);
            turnAround();

            if(colsCounter > rowsCounter) {
                continuousMoveAndCount((colsCounter / 2) - num1);
                turnRight();

                continuousDraw((num1));
                turnLeft();
                continuousDraw((num1 * 2));
                turnLeft();
                continuousDraw((num1 * 2)-1);
                turnLeft();
                continuousDraw((num1 * 2));
                turnLeft();
                continuousDraw((num1));
            }
            else{
                continuousMoveAndCount((colsCounter / 2+1) - num1);
                turnRight();

                continuousDraw((num1)-1);
                turnLeft();
                continuousDraw((num1 * 2)-2);
                turnLeft();
                continuousDraw((num1 * 2)-3);
                turnLeft();
                continuousDraw((num1 * 2)-2);
                turnLeft();
                continuousDraw((num1));
            }
        }
        else if (rowsCounter % 2 == 0 && colsCounter % 2 == 1){

            continuousMoveAndCount(Math.floor(colsCounter /2 ));
            turnLeft();

            DrowLeft(rowsCounter);

            continuousMoveAndCount((rowsCounter /2));
            turnRight();

            continuousDraw((colsCounter /2) );
            DrawRight();

            continuousDraw(colsCounter);
            DrawRight();

            continuousDraw((colsCounter /2) );
            turnLeft();
            moveAndCount();

            int Min = Math.min(colsCounter, rowsCounter);
            int num = (Min/2) - 2;

            if(colsCounter > rowsCounter) {
                continuousMoveAndCount(num - 1);
                turnLeft();
                checkAndPutBeeper();
                moveAndCount();

                DrawAndGoLeft(num - 1);
                DrawAndGoLeft((num * 2) + 2);
                DrawAndGoLeft((num * 2) + 1);
                DrawAndGoLeft((num * 2) + 2);
                continuousDraw(num);
            }
            else{
                continuousMoveAndCount(num);
                turnLeft();
                checkAndPutBeeper();
                moveAndCount();

                DrawAndGoLeft(num);
                DrawAndGoLeft((num * 2) + 4);
                DrawAndGoLeft((num * 2) + 3);
                DrawAndGoLeft((num * 2) + 4);
                continuousDraw(num+1);
            }
        }
    }

    public void run() {
        setBeepersInBag(10000000);
        colsCounter = 1; rowsCounter = 1 ; moveCount = 0;
        CountRowAndCol();
        if(colsCounter < 7 || rowsCounter < 7){
            System.out.println("Sorry the Height and the the Offer are very small");
        }
        else {
            Draw();
        }
        System.out.println("RowCounter = " + rowsCounter);
        System.out.println("ColCounter = " + colsCounter);
        System.out.println("MoveCount = " + moveCount);
    }

}
